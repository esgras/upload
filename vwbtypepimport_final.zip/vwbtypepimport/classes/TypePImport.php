<?php

class TypePImport extends ObjectModel
{

    public $id_type_pimport;
    public $id_feature_value;
    public $name;

    public static $definition = array(
        'primary' => 'id_type_pimport',
        'table' => 'type_pimport',
        'multilang' => false,

        'fields' => array(
            'id_feature_value' => array('type' => self::TYPE_INT, 'validate' => 'isUnsignedInt', 'required' => true),
            'name' => array('type' => self::TYPE_STRING, 'validate' => 'isCleanHtml', 'required' => true)
        ),
    );

    public static function findAll() {
        return Db::getInstance()->executeS('SELECT * FROM ' . _DB_PREFIX_ . 'type_pimport');
    }

    public static function findById($id) {
        $all = self::findAll();

        foreach ($all as $key => $val) {
            if ($val['id_type_pimport'] == $id) {
                return array(
                    'id_type_pimport' => $val['id_type_pimport'],
                    'id_feature_value' => $val['id_feature_value'],
                    'name' => $val['name']
                );
            }
        }

        return [];
    }
}