CREATE TABLE PREFIX_type_pimport (
  id_type_pimport INT NOT  NULL AUTO_INCREMENT,
  id_feature_value INT NOT NULL,
  name varchar(255) NOT NULL,
  PRIMARY KEY (id_type_pimport)
);