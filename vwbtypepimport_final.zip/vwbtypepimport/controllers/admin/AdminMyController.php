<?php

require_once __DIR__ . '/../../classes/TypePImport.php';

class AdminMyController  extends ModuleAdminController
{

    public function __construct()
    {
        $this->bootstrap = true;
        $this->table = 'type_pimport';
        $this->className = 'TypePImport';
        #$this->list_no_link = true;

        parent::__construct();/* Join categories table */

        $this->_join .= ' LEFT JOIN ' . _DB_PREFIX_ . 'feature_value_lang fvl ON fvl.id_feature_value = a.id_feature_value';
        $this->_select .= ' fvl.value';
        $this->_where .= ' AND fvl.id_lang=' . $this->context->language->id;

        $this->fields_list = array();
        $this->fields_list['id_type_pimport'] = array(
            'title' => $this->l('ID'),
            'align' => 'center',
            'class' => 'fixed-width-xs',
            'type' => 'int'
        );

        $this->fields_list['name'] = array(
            'title' => $this->l('Type'),
        );

        $this->fields_list['value'] = array(
            'title' => $this->l('Feature Value'),
            'filter_key' => 'fvl!value'
        );

        $this->addRowAction('edit');
        $this->addRowAction('delete');

    }


    public function renderList()
    {

        if (!($this->fields_list && is_array($this->fields_list))) {
            return false;
        }
        $this->getList($this->context->language->id);


        $helper = new HelperList();

        // Empty list is ok
        if (!is_array($this->_list)) {
            $this->displayWarning($this->l('Bad SQL query', 'Helper') . '<br />' . htmlspecialchars($this->_list_error));
            return false;
        }

        $this->setHelperDisplay($helper);
        $helper->_default_pagination = $this->_default_pagination;
        $helper->_pagination = $this->_pagination;
        $helper->tpl_vars = $this->getTemplateListVars();
        $helper->tpl_delete_link_vars = $this->tpl_delete_link_vars;

        // For compatibility reasons, we have to check standard actions in class attributes
        foreach ($this->actions_available as $action) {
            if (!in_array($action, $this->actions) && isset($this->$action) && $this->$action) {
                $this->actions[] = $action;
            }
        }

        $helper->is_cms = $this->is_cms;
        $helper->sql = $this->_listsql;
        $list = $helper->generateList($this->_list, $this->fields_list);

        return $list;
    }



    public function renderForm()
    {

        $featureList = PimportFeatureHelper::getFeatureListByFeatureNameAndLanguage('Тип', $this->context->language->id);
        $id = (int) Tools::getValue('id_type_pimport');

        if (Tools::isSubmit('type_pimport_submit')) {
            $model = !empty($id) ? new TypePImport($id) : new TypePImport();

            $model->id_feature_value = Tools::getValue('id_feature_value');
            $model->name = Tools::getValue('name');

            if ($model->id) {
                $model->update();
            } else {
                $model->add();
            }

            $id = $model->id;

            $uri = self::$currentIndex . '&id_type_pimport='.$id
                . '&updatetype_pimport&token='.$this->token;
            header('Location: ' . $uri);
            exit;
        }
        

        $row = TypePImport::findById($id);

          $fields_form = array(
            'form' => array(
                'legend' => array(
                    'title' => $this->l('My Type List'),
                    'icon' => 'icon-envelope'
                ),

                'input' => array(
                   array(
                       'type' => 'text',
                       'label' => $this->l('Type Name'),
                       'size' => 30,
                       'name' => 'name',
                   ),

                    array(
                        'type' => 'select',
                        'label' => $this->l('Feature Value:'),
                        'name' => 'id_feature_value',
                        'desc' => $this->l('Feature Value list'),
                        'options' => array(
                           'query' => $featureList,

                            'id' => 'id',
                            'name' => 'val'
                        ),
                    ),
                ),

                'submit' => array(
                    'title' => $this->l('Save')
                ),
            ),
        );


        $helper = new HelperForm;
        $helper->table = 'type_pimport';
        $helper->default_form_language = (int) Configuration::get('PS_LANG_DEFAULT');
        $helper->allow_employee_form_lang =  (int) Configuration::get('PS_BO_ALLOW_EMPLOYEE_FORM_LANG');
        $helper->submit_action = 'type_pimport_submit';

        $helper->currentIndex = self::$currentIndex .
                ($id > 0 ? '&id_type_pimport='.$id. '&updatetype_pimport' : '&addtype_pimport');#'&token='.$this->token;


        $helper->token = $this->token;

        $helper->tpl_vars = array(
            'fields_value' => array(
                'id_feature_value' => isset($row['id_feature_value']) ? $row['id_feature_value'] : null,
                'name' => isset($row['name']) ? $row['name'] : null,
            ),

            'languages' => $this->context->controller->getLanguages()
        );

        return $helper->generateForm(array($fields_form));
    }


    public function getTypeById($id)
    {
        
    }
}