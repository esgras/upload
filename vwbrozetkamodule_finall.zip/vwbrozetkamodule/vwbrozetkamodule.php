<?php

if (!defined('_PS_VERSION_')) {
    exit;
}


class VwbRozetkaModule extends Module
{
    private $fieldName;
    private $template;
    private $localDir;

    private $configs = array(
        'ROZETKA_FILE',
        'ROZETKA_COMPANY',
        'ROZETKA_NAME',
        'ROZETKA_MANUFACTURERS'
    );

    public function __construct()
    {
        $this->name = 'vwbrozetkamodule';
        $this->version = '1.0.0';
        $this->author = 'ViWeb';
        $this->tab = 'front_office_features';
        $this->bootstrap = true;

        $this->fieldName = 'description_rozetka';
        $this->template = 'override/controllers/admin/templates/products/informations.tpl';
           $this->localDir = __DIR__ . '/';

        parent::__construct();
        $this->displayName = $this->l('VWB Module for creating XML file to Rozetka');
        $this->description = $this->l('This module let you create xml feed by choosing manufacturer list...');
        $this->ps_versions_compliancy = array('min' => '1.6', 'max' => '1.6.9');
    }

    public function install()
    {



        if (!$this->installTemplateFile()
            ||
        !$this->loadSqlFromFile(__DIR__ . '/install/install.sql')
        ) {
            return false;
        }

        #return false;

       if (!parent::install()) {
            return false;
        }


        Configuration::updateValue('ROZETKA_FILE', 'rozetka.xml');

        return true;
    }

    public function uninstall()
    {
        if (!parent::uninstall()) {
            return false;
        }


        
        if (
            !$this->removeTemplateFile()
            ||
            !$this->removeTemplate()

            ||
             !$this->loadSqlFromFile(__DIR__ . '/install/uninstall.sql')
        ) {
            return false;
        }

        Configuration::deleteByName('ROZETKA_FILE');
        Configuration::deleteByName('ROZETKA_COMPANY');
        Configuration::deleteByName('ROZETKA_NAME');
        Configuration::deleteByName('ROZETKA_MANUFACTURERS');


        return true;
    }


    public function loadSqlFromFile($file)
    {
        $sqlContent = file_get_contents($file);
        $sqlContent = str_replace('PREFIX_', _DB_PREFIX_, $sqlContent);
        $sqlContent = str_replace('FIELD_NAME', $this->fieldName, $sqlContent);
        $queries = preg_split('#;\s*[\r\n]*#', $sqlContent, -1, PREG_SPLIT_NO_EMPTY);

        $res = true;
        #var_dump($queries);
        foreach ($queries as $query) {
        #    die($query);
            $res &= DB::getInstance()->execute(trim($query));
        }

        return $res;
    }

    public function getContent()
    {
        $rozetka_manufacturers = Tools::getValue('rozetka_manufacturers');

        if (Tools::isSubmit('submitChangeBrands')) {
            $name = substr(Tools::getValue('rozetka_name'), 0, 20);
            $company = Tools::getValue('rozetka_company');
            Configuration::updateValue('ROZETKA_NAME', $name);
            Configuration::updateValue('ROZETKA_COMPANY', $company);
            Configuration::updateValue('ROZETKA_MANUFACTURERS',  serialize($rozetka_manufacturers));
        }

        $name = substr(Tools::getValue('rozetka_name', Configuration::get('ROZETKA_NAME')), 0, 20);
        $company = Tools::getValue('company_name', Configuration::get('ROZETKA_COMPANY'));
        $manufacturers = $this->getManufacturersList();
        $rozetka_manufacturers = unserialize(Configuration::get('ROZETKA_MANUFACTURERS'));
        if (!is_array($rozetka_manufacturers)) {
            $rozetka_manufacturers = array();
        }

        $file = Configuration::get('ROZETKA_FILE');

        $fileLink = _PS_BASE_URL_ . '/upload/' . $file;


        $token = Tools::getAdminTokenLite('AdminModules');
        $link =  $this->context->link->getAdminLink('AdminModules', false).'&configure='.$this->name
            .'&tab_module='.$this->tab.'&name='.$this->name
            .'&token=' . $token;

        $controllerLink = $this->context->link->getModuleLink('vwbrozetkamodule', 'rozetka');

        $this->context->smarty->assign(array(
            'action' => $link,
            'controllerLink' => $controllerLink,
            'rozetka_name' => $name,
            'rozetka_company' => $company,
            'fileLink' => $fileLink,
            'manufacturers' => $manufacturers,
            'rozetka_manufacturers' => $rozetka_manufacturers
        ));

        return $this->display(__FILE__, 'form.tpl');
    }

    private function installCustomTemplates()
    {

        $customTemplates = array(
            'override/controllers/admin/templates/products/informations.tpl',
        );
        $localPath = __DIR__  . '/';

        $success = true;
        foreach ($customTemplates as $ct) {
            $destination = _PS_ROOT_DIR_.'/'.$ct;
            $customTemplate = $localPath.$ct;

            if (!Tools::file_exists_cache($destination) && Tools::file_exists_cache($customTemplate)) {
                $template_directory = dirname($destination);
                if (!Tools::file_exists_no_cache($template_directory)) {
                    $success = $success && @mkdir($template_directory, 0755, true);
                }
                $success = $success && @copy($customTemplate, $destination);

                do {
                    if (Tools::file_exists_cache(_PS_ROOT_DIR_.'/config/index.php') && !Tools::file_exists_cache($template_directory.'/index.php')) {
                        $success = $success && @copy(_PS_ROOT_DIR_.'/config/index.php', $template_directory.'/index.php');
                    }
                    $template_directory = dirname($template_directory);

                } while (strlen(_PS_ROOT_DIR_) < strlen($template_directory));

            }
        }
        return $success;
    }


    private function installTemplateFile()
    {


        $res = true;

        $destination = _PS_ROOT_DIR_ . '/' . $this->template;
        $templateFile = $this->localDir . $this->template;

        if (!is_file($destination)) {
            $templateDir = dirname($destination);

            if (!$this->isPathDirWritable(_PS_ROOT_DIR_ , $templateDir)) {
                    return false;
            }



            if (!is_dir(dirname($destination))) {
                $res &= mkdir($templateDir, 0755, true);
            }

            $res &= @copy($templateFile, $destination);

            while (strlen(_PS_ROOT_DIR_ ) < $templateDir) {

                //add index.php file (presta defense) to all dirs in tree
                $indexFile = $templateDir . '/index.php';
                if (!file_exists($indexFile)) {
                    $res &= @copy(_PS_ROOT_DIR . '/config/index.php', $indexFile);
                }

                $templateDir = dirname($templateDir);
            }
        }

        //проверяю что файл есть и доступен для записи
        if (!$this->isPathWritable($destination)) {
                return false;
        }

        return $res;
    }


    //Check that module can make dirs from path and can copy a file to fullPath dir
    private function isPathDirWritable($startDir, $fullPath) {
        $str = rtrim(str_replace($startDir, '', $fullPath), '/');

        $path = _PS_ROOT_DIR_;
        $dirs = explode('/', $str);

        //check dirs from path
        foreach ($dirs as $dir) {
            $path .= $dir . '/' ;
            $parentDir = dirname($path);

            if (!is_dir($path) && !is_writable($parentDir)) {
                $this->_errors[] = Tools::displayError($this->l(
                    "You don't have permission to create dir - " . basename($path) ." at path " . $parentDir
                ));

                return false;
            }
        }

        return true;
    }

    private function isPathWritable($path) {
        if (!is_writable($path)) {
            $this->_errors[] = Tools::displayError($this->l(
                "You don't have permission to create files in dir  $path "
            ));

            return false;
        }

        
        return true;
    }


    private function removeTemplateFile() {
        $destination = _PS_ROOT_DIR_ . '/' . $this->template;
        $res = true;

        if (is_file($destination)) {
            if (!is_writable(dirname($destination))) {
                $this->_errors[] = Tools::displayError($this->l("Your don't have permission to delete files in dir " . dirname($destination)));
                return false;
            }

            $res &= unlink($destination);
        }

        return $res;
    }

    public function removeTemplate() {

        $file = Configuration::get('ROZETKA_FILE');
        //d(_PS_BASE_URI_);

        $destination = _PS_BASE_DIR_ . '/upload/' . $file;

       
        if (!is_file($destination)) {
            return true;
        }

        if (is_writable(dirname($destination))) {
            unlink($destination);
            return true;
        }

        $this->displayConfirmation('File ' . $destination . ' was not deleted');
        return true;

    }

    public function getManufacturersList()
    {
        $sql = "SELECT * FROM " . _DB_PREFIX_ . "manufacturer";
        $mans = DB::getInstance()->executeS($sql);

        return $mans;
    }


}
