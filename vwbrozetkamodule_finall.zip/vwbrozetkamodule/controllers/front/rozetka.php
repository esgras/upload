<?php

include_once _PS_MODULE_DIR_ . 'vwbrozetkamodule/classes/Rozetka.php';
include_once _PS_MODULE_DIR_ . 'vwbrozetkamodule/classes/RozetkaFeatureHelper.php';

class VwbRozetkaModuleRozetkaModuleFrontController extends ModuleFrontController {

    public function initContent()
    {

        parent::initContent();
        $this->generate();

    }

    public function generate()
    {


        //здесь достаем там где name - вкус
       /* echo "<pre>";
        $prod = new Product(1);
        var_dump($prod->getFrontFeatures(1));
        die();*/


        $res = RozetkaFeatureHelper::getProductFeatureList(1, 1);
       /* if (defined('_PS_MODE_DEV_')) {
            d(array(
                'data' => $res,
                'place' => __FILE__ . ':' . __LINE__
            ));
        }*/

        $filename = Configuration::get('ROZETKA_FILE');
        if (empty($filename)) {
            $filename = 'rozetka.xml';
        }

        $model = new Rozetka($this, _PS_UPLOAD_DIR_ . $filename);

        try {
            $model->generate();
            echo '<h2><a href="'. _PS_BASE_URL_ . '/upload/' . $filename . '">Сгенерированный xml файл</a>';
            die;
        } catch (Exception $ex) {
            $message = '<h1 style="color: #333;">' . $ex->getMessage() . '</h1>';
            die($message);
        }
    }
}
