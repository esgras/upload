<?php

Product::$definition['fields']['description_rozetka'] = array('type' => ObjectModel::TYPE_HTML, 'lang' => true, 'validate' => 'isCleanHtml');

class Product extends ProductCore
{
    public $description_rozetka;
}