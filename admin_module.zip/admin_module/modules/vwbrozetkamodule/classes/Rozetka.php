<?php

require_once __DIR__ . '/RozetkaFeatureHelper.php';

class Rozetka
{
    public $context;
    private $fileHandler;
    private $filename;
    public $name;
    public $company;
    public $currencyName;
    public $langId;
    public $module;
    private $featureInfo = array();


    public function __construct($module, $filename)
    {
        $this->context = Context::getContext();
        $this->name = Configuration::get('ROZETKA_NAME');
        $this->company = Configuration::get('ROZETKA_COMPANY');

        $this->currencyName = $this->getCurrency();
        $this->module = $module;

        $this->langId = $this->context->language->id;
        $this->filename = $filename;
    }

    public function generate()
    {

        $this->prepareFileToWork();

        $this->write($this->xmlHeader());
        $this->write($this->xmlStartRootDirectory());
        $this->write($this->xmlCategories());
        $this->write($this->xmlOffers());
        $this->write($this->xmlEndRootDirectory());

        $this->closeWorkWithFile();
    }

    public function prepareFileToWork()
    {
        $dir = dirname($this->filename);

        if (!is_dir($dir)) {
            throw new Exception($this->module->l('Directory ' . $dir . ' doesn\'t exist.'));
        }


        if (!is_writable($dir)) {
            throw new Exception($this->module->l('You don\'t have permissions to write to ' . $dir));
        }

        if (!is_file($this->filename)) {
            touch($this->filename);
        }

        $this->fileHandler = fopen($this->filename, 'w');
    }

    public function closeWorkWithFile()
    {
        if (is_resource($this->fileHandler)) {
            fclose($this->fileHandler);
        }
        $this->fileHandler = null;
    }

    public function xmlHeader()
    {
        return '<?xml version="1.0" encoding="UTF-8"?><!DOCTYPE yml_catalog SYSTEM "shops.dtd">';
    }

    public function xmlStartRootDirectory()
    {
        $out = '<yml_catalog date="' . date('Y-m-d H:i') . '"><shop>';
        $out .= '<name>' . $this->name . '</name>';
        $out .= '<company>' . $this->company . '</company>';
        $out .= '<url>' . _PS_BASE_URL_ . '</url>';
        $out .= '<currencies><currency id="' . $this->currencyName . '" rate="1"/></currencies>';

        return $out;
    }

    public function xmlCategories()
    {

        $categories = $this->getCategoriesData($this->langId);
        $out = '<categories>';
        foreach ($categories as $category) {
            if ($category['id_category'] == 1) continue;

            $parentId = !empty($category['id_parent']) ? ' parentId="' . $category['id_parent'] . '"' : '';
            $out .= '<category id="' . $category['id_category'] . '"' .
                $parentId . '>' . $category['name'] . '</category>';
        }
        $out .= '</categories>';
        return $out;
    }

    public function getCategoriesData($langId)
    {
        $sql = "SELECT c.id_category, c.id_parent, cl.name 
                FROM " . _DB_PREFIX_ . "category as c
                LEFT JOIN " . _DB_PREFIX_ . "category_lang as cl ON (c.id_category = cl.id_category)               
                WHERE c.active = 1 AND cl.id_lang = " . (int)$langId
            . " AND cl.id_shop=" . (int)$this->context->shop->id;
        $categories = Db::getInstance()->executeS($sql);
        return $categories;
    }

    public function getManufacturersList()
    {
        $manufacturers = unserialize(Configuration::get('ROZETKA_MANUFACTURERS'));
        if (!empty($manufacturers)) {
            $where = ' WHERE id_manufacturer IN (' . join(',', $manufacturers) . ')';
        } else {
            $where = '';
        }

        $sql = "SELECT id_manufacturer FROM " . _DB_PREFIX_ . "manufacturer" . $where;
        $mans = DB::getInstance()->executeS($sql);
        return $mans;
    }

    public function getProductByManufacturerId($manId)
    {

        $sql = "SELECT p.id_product id_product, p.id_category_default id_category_default, 
                       p.active available, p.price price, 
                       pl.description_short description_rozetka, pl.name product_name, m.name manufacturer_name
                FROM " . _DB_PREFIX_ . "product as p
                LEFT JOIN " . _DB_PREFIX_ . "product_lang pl ON (p.id_product = pl.id_product)
                LEFT JOIN " . _DB_PREFIX_ . "manufacturer m ON (p.id_manufacturer = m.id_manufacturer)
                -- LEFT JOIN " . _DB_PREFIX_ . "product_shop ps ON (p.id_product = ps.id_product)
                WHERE pl.id_lang = " . $this->langId . " AND m.id_manufacturer = " . $manId . " AND p.active = 1
                AND pl.id_shop = " . (int)$this->context->shop->id;

        return Db::getInstance()->executeS($sql);
    }

    public function xmlOffers()
    {
        $manufacturers = $this->getManufacturersList();
        $out = '<offers>';

        foreach ($manufacturers as $man) {
            $products = $this->getProductByManufacturerId($man['id_manufacturer']);

            $out .= $this->xmlOffersByProductList($products);
        }
        $out .= '</offers>';
        return $out;
    }


    public function getSimpleFeatures($features)
    {
        $feats = array();
        foreach ($features as $key => $val) {
            if (!is_array($val)) {
                $feats[$key] = $val;
            }
        }

        return $feats;
    }

    public function getComplexFeatures($features)
    {
        $feats = array();
        foreach ($features as $key => $val) {
            if (is_array($val)) {
                $feats[$key] = $val;
            }
        }

        return $feats;
    }

    public function xmlOffersByProductList($products)
    {
        if (!is_array($products) || empty($products))
            return '';

        $out = '';

        //Старый код
        #$specialKeyName = 'Вкус';

        foreach ($products as $product) {

            //Выделить в отдельный блок

            $data = $this->getFeatureListByProductId($product['id_product']);

            $prod = new Product($product['id_product']);

            /* @TODO заглушка на локалке при переносе убрать */
            if (!property_exists($prod, 'filling')) {
                $prod->filling = '100г';
            }

            $filling = $prod->filling;
            if ($filling != null) {
                 $product['filling'] = $filling;
            }

            //отделяю фичи с одиночным значением от фич с множественным значением
            $simpleFeatures = $this->getSimpleFeatures($data);

#            var_dump($simpleFeatures); die;


            $complexFeatures = $this->getComplexFeatures($data);

            $xmlSimpleFeatures = $this->xmlFromFeatureInfo($simpleFeatures);

            //Если есть сложные фичи для каждой прийдеться делать отдельный offer
            if (!empty($complexFeatures)) {
                $this->recFeatureInfo($complexFeatures, array_keys($complexFeatures));

                $id = $product['id_product'];
                $firstTime = true;
                foreach ($this->featureInfo as $featureList) {
                     //для 1-го офера из серии id не меняем
                     if ($firstTime) {
                         $firstTime = false;
                     } else {
                         $product['id_product'] = $this->getRandomId($id);
                     }

                     $out .= $this->xmlOfferProductForFeature($product,
                        $xmlSimpleFeatures . $this->xmlFromFeatureInfo($featureList));
                }

                $this->clearFeatureInfo();
            } else {
                $out .= $this->xmlOfferProductForFeature($product, $xmlSimpleFeatures);
            }



            //Старый код
            //Создаю объект дефолтных значений
            /*
            foreach ($data as $key => $val) {
                if ($key != $specialKeyName) {
                    if (is_array($val)) {
                        $simpleFeatureInfo[$key] = $val[0];
                    } else {
                        $simpleFeatureInfo[$key] = $val;
                    }
                }

               # $simpleFeatureInfo['id'] = $product['id_product'];
            }

            if (isset($data[$specialKeyName])) {
                if (is_array($data[$specialKeyName])) {
                    $firstTime = true;
                    $id = $product['id_product'];
                    foreach ($data[$specialKeyName] as $val) {
                        //если у несколько вкусов у первого элемента - нормальный id
                        //у остальных с префиксом
                        if ($firstTime) {

                            $firstTime = false;
                            $prodId = $id;
                        } else {
                            $prodId = $this->getRandomId($id);
                        }

                        $product['id_product'] = $prodId;


                        $simpleFeatureInfo[$specialKeyName] = $val;

                        $featuresInfo = $this->xmlFromFeatureInfo($simpleFeatureInfo);

                        $product[$specialKeyName] = $val;
                        $out .= $this->xmlOfferProductForFeature($product, $featuresInfo);
                    }
                } else {
                    $simpleFeatureInfo[$specialKeyName] = $data[$specialKeyName];
                    $featuresInfo = $this->xmlFromFeatureInfo($simpleFeatureInfo);

                    $product[$specialKeyName] = $data[$specialKeyName];
                    $out .= $this->xmlOfferProductForFeature($product, $featuresInfo);

                }
            } else {

                $featuresInfo = $this->xmlFromFeatureInfo($simpleFeatureInfo);

                $out .= $this->xmlOfferProductForFeature($product, $featuresInfo);


            }
            */
        }

        return $out;
    }

    public function xmlOfferProductForFeature($product, $featureInfo)
    {
        $catObject = new Category($product['id_category_default']);
        $catName = $catObject->getName($this->langId);


        $out = '<offer id="' . $product['id_product'] . '" available="'
            . ($product['available'] ? 'true' : 'false') . '">';

        $out .= '<url>' . $this->e($this->context->link->getProductLink($product['id_product'])) . '</url>';
        $out .= '<price>' . round($product['price'], 2) . '</price>';
        $out .= '<currencyId>' . $this->currencyName . '</currencyId>';
        $out .= '<categoryId>' . $product['id_category_default'] . '</categoryId>';

        $out .= $this->xmlPicturesByProductId($product['id_product']);

        $name = '<name>'

            . $this->e($catName) . ' '
            . $this->e($product['product_name']) . $this->e($product['manufacturer_name'])
        . (isset($product['filling']) ? ' ' . $this->e($product['filling']) : '')
        . (isset($product['Вкус']) ? ' ' . $this->e($product['Вкус']) : '')
            . '</name>';
        $out .= $name;
        $out .= '<vendor>' . $this->e($product['manufacturer_name']) . '</vendor>';


        $out .= '<description><![CDATA[' . $this->e($product['description_rozetka']) . ']]></description>';
        $out .= $featureInfo;
        $out .= '</offer>';
        return $out;
    }

    public function getRandomId($id)
    {
        return $id . '_' . rand(0, 1000);
    }


    //Пытаюсь сделать XML From ProductInfo
    public function xmlFromFeatureInfo($featureInfo)
    {
        $out = '';

        foreach ($featureInfo as $key => $feature) {
            $out .= '<param name="' . $key . '">' . $this->e($feature) . '</param>';
        }

        return $out;
    }


    public function xmlPicturesByProductId($productId)
    {
        $prod = new Product($productId);
        $images = $prod->getImages($this->langId);

        $out = '';
        foreach ($images as $image) {
            $imageUrl = $this->context->link->getImageLink($prod->link_rewrite[$this->langId], $image['id_image']);
            $out .= '<picture>' . $imageUrl . '</picture>';
        }

        return $out;
    }

    public function getFeatureListByProductId($prodId)
    {
        $features = RozetkaFeatureHelper::getProductFeatureList($this->langId, $prodId);

        $res = array();
        $names = array();

        //Получить все входящие названия параметров атрибутов
        foreach ($features as $feature) {
            $names[] = $feature['name'];
        }

        //Получить количество появлений каждого названия параметра
        $countOfNames = array_count_values($names);

        foreach ($features as $feature) {
            if ($countOfNames[$feature['name']] > 1) {
                $res[$feature['name']][] = $feature['value'];
            } else {
                $res[$feature['name']] = $feature['value'];
            }
        }

        return $res;

    }

    public function xmlFeaturesByProductId($prodId)
    {

        $f = $this->getFeatureListByProductId($prodId);
        return $f;

        $features = RozetkaFeatureHelper::getProductFeatureList($this->langId, $prodId);
        $out = '';


        foreach ($features as $feature) {
            $out .= '<param name="' . $feature['name'] . '">' . $this->e($feature['value']) . '</param>';
        }

        return $out;
    }


    //Рекурсивная функция для построяния разных featureInfo при нескольких значениях feature с одним именем в продукте
    //Сюда должны пойти только те фичи у которых несколько значений

    public function recFeatureInfo($arr, $indexKeys, $keyIndex = 0, $a2 = []) {
        if (!isset($indexKeys[$keyIndex])) {
            $this->addToFeatureInfo($a2);
            return;
        }


        $key =  $indexKeys[$keyIndex];
        $newKeyIndex = $keyIndex + 1;

        foreach ($arr[$key] as $elem) {
            if ($keyIndex == 0) {
                $a2 = [];
            }

            $a2[$key] = $elem;

            $this->recFeatureInfo($arr, $indexKeys, $newKeyIndex, $a2);
        }
    }

    //Вспомогательные функции для работы с рекурсивной функцией
    private function addToFeatureInfo(array $arr) {
        $this->featureInfo[] = $arr;
    }

    private function clearFeatureInfo() {
        $this->featureInfo = array();
    }


    public function getCurrency()
    {
        return Db::getInstance()->getValue("SELECT iso_code FROM " . _DB_PREFIX_ . "currency "
            . " WHERE id_currency = " . $this->context->cart->id_currency);
    }

    public function xmlEndRootDirectory()
    {
        return '</shop></yml_catalog>';
    }

    public function write($text)
    {
        fwrite($this->fileHandler, $text);
    }

    public function e($text)
    {
        return htmlspecialchars($text, ENT_QUOTES, 'UTF-8');
    }

}
