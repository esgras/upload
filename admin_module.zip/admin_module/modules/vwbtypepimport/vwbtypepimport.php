<?php

if (!defined('_PS_VERSION_')) {
    exit;
}


require_once __DIR__ . '/classes/FeatureHelper.php';
require_once(dirname(__FILE__).'/classes/TypePImport.php');

class VwbTypePImport extends Module
{
    private $adminTypes;


    public function __construct()
    {
        $this->name = 'vwbtypepimport';
        $this->version = '1.0.0';
        $this->author = 'ViWeb';
        $this->tab = 'front_office_features';
        $this->bootstrap = true;


        parent::__construct();
        $this->displayName = $this->l('VWB Module for Making list for type');
        $this->description = $this->l('VWB Module for Making list for type');
        $this->ps_versions_compliancy = array('min' => '1.6', 'max' => '1.6.9');
    }

    public function install()
    {
        if (!parent::install()
            ||
            !$this->loadSqlFromFile(__DIR__ . '/install/install.sql')
        ) return false;

        if (!$this->installTab('AdminCatalog', 'AdminTypePImport', 'PImport'))
            return false;

        return true;
    }

    public function getAdminTypeById($id)
    {
        //$result = null;
        foreach ($this->adminTypes as $type) {
            if ($type['id'] == $id) return $type;
        }

        return null;
    }

    public function uninstall()
    {
        if (!parent::uninstall()
            ||
            !$this->loadSqlFromFile(__DIR__ . '/install/uninstall.sql')
        )
            return false;

        if (!$this->uninstallTab('AdminTypePImport')) return false;

        return true;
    }

    public function uninstallTab($class_name)
    {
        //	Retrieve	Tab	ID
        $id_tab = (int)Tab::getIdFromClassName($class_name);
        //	Load	tab
        $tab = new    Tab((int)$id_tab);
        //	Delete	it
        return $tab->delete();
    }


    public function loadSqlFromFile($file)
    {
        $sqlContent = file_get_contents($file);
        $sqlContent = str_replace('PREFIX_', _DB_PREFIX_, $sqlContent);
        $sqlContent = str_replace('FIELD_NAME', $this->fieldName, $sqlContent);
        $queries = preg_split('#;\s*[\r\n]*#', $sqlContent, -1, PREG_SPLIT_NO_EMPTY);

        $res = true;

        foreach ($queries as $query) {
            $res &= DB::getInstance()->execute(trim($query));
        }

        return $res;
    }

    public function getListOfIds()
    {
        $ids = [];

        /* if (defined('_PS_MODE_DEV_')) {
             d(array(
                 'data' => $this->adminTypes,
                 'place' => __FILE__ . ':' . __LINE__
             ));
         }*/

        foreach ($this->adminTypes as $type) {
            $ids[] = $type['id'];
        }

        return $ids;
    }

    public function updateExistValues($names, $id_feature_values)
    {
        foreach ($names as $key => $name) {
            if (!in_array($key, $this->getListOfIds())) continue;

            $type = $this->getAdminTypeById($key); //continue;

            if ($type['id_feature_value'] == (int)$id_feature_values[$key]
                && $type['name'] === $names[$key]
            ) continue;

            $update = array(
                'name' => pSQL($names[$key]),
                'id_feature_value' => $id_feature_values[$key]
            );

            Db::getInstance()->update('type_pimport', $update, 'id_type_pimport=' . (int)$key);
        }
    }

    public function addNewValues($names, $id_feature_values)
    {
        foreach ($names as $key => $name) {

            if (in_array($key, $this->getListOfIds()) || empty($names[$key])) continue;

            /*
                        $sql = 'INSERT INTO ' . _DB_PREFIX_ . 'type_pimport (name, id_feature_value) VALUES("' .
                            pSQL($names[$key]) . '",' . (int) $id_feature_values[$key] . '
                        )';*/

            $insert = array(
                'name' => pSQL($names[$key]),
                'id_feature_value' => (int)$id_feature_values
            );


            Db::getInstance()->insert('type_pimport', $insert);
        }


    }


    public function processContent()
    {

        $keyField = 'submitChange';


        if (Tools::isSubmit($keyField)) {
            $name = Tools::getValue('name');
            $id_feature_value = Tools::getValue('id_feature_value');


            $this->updateExistValues($name, $id_feature_value);
            $this->addNewValues($name, $id_feature_value);

        }
    }

    public function assignContent()
    {
        $this->loadData();
        $adminTypes = $this->adminTypes;


        $maxId = 0;
        foreach ($adminTypes as $type) {
            if ($type['id'] > $maxId) $maxId = $type['id'];
        }

        $maxId++;

        $this->context->smarty->assign(array(
            'adminTypes' => $adminTypes,
            'countOfRows' => count($adminTypes) - 1,
            'maxId' => $maxId
        ));
    }

    public function loadData()
    {
        $this->adminTypes = $adminTypes = Db::getInstance()->executeS('SELECT id_type_pimport id, id_feature_value, name FROM ' . _DB_PREFIX_ . 'type_pimport');

    }

    public function installTab($parent, $class_name, $name)
    {
        //	Create	new	admin	tab

       /* echo "INSTALL TAB";
        die;*/

        $tab = new Tab();
        $tab->id_parent = (int)Tab::getIdFromClassName($parent);
        $tab->name = array();
        foreach (Language::getLanguages(true) as $lang)
            $tab->name[$lang['id_lang']] = $name;
        $tab->class_name = $class_name;
        $tab->module = $this->name;
        $tab->active = 1;
        return $tab->add();
    }

    public function getContent()
    {

        $this->loadData();

        $this->processContent();
        $this->assignContent();

        $featureName = 'Тип';
        $langId = $this->context->language->id;





        /* $sql = "SELECT id_feature
                 FROM `ps_feature_lang`
                 WHERE id_lang = " . $langId . "
                 AND name = 'Тип'";*/


        $features = FeatureHelper::getFeatureListByFeatureNameAndLanguage($featureName, $langId);

        $token = Tools::getAdminTokenLite('AdminModules');
        $link = $this->context->link->getAdminLink('AdminModules', false) . '&configure=' . $this->name
            . '&tab_module=' . $this->tab . '&name=' . $this->name
            . '&token=' . $token;


        $this->context->smarty->assign(array(
            'action' => $link,
            'features' => $features
        ));

        return $this->display(__FILE__, 'form.tpl');
    }


}
