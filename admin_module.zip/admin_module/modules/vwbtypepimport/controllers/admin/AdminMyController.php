<?php

class AdminMyController  extends ModuleAdminController
{

    public function __construct()
    {
        $this->bootstrap = true;
        $this->table = 'type_pimport';
        $this->className = 'Product';
        #$this->lang = true;
        $this->list_no_link = true;
        #$this->override_folder = false;

        parent::__construct();/* Join categories table */
/*
        echo '<pre>';
        var_dump($this);
        die;*/

        /*$this->fields_list = array(

        );*/

        /*$this->bulk_actions = array(
            'delete' => array(
                'text' => $this->l('Delete selected'),
                'confirm' => $this->l('Delete selected items?'),
                'icon' => 'icon-trash'
            )
        );*/


        $this->_join .= ' LEFT JOIN ' . _DB_PREFIX_ . 'feature_value_lang fvl ON fvl.id_feature_value = a.id_feature_value';
        $this->_select .= ' fvl.value';
        $this->_where .= ' AND fvl.id_lang=' . $this->context->language->id;

        $this->fields_list = array();
        $this->fields_list['id_type_pimport'] = array(
            'title' => $this->l('ID'),
            'align' => 'center',
            'class' => 'fixed-width-xs',
            'type' => 'int'
        );

        $this->fields_list['value'] = array(
            'title' => $this->l('Name'),
            'filter_key' => 'fvl!value'
        );

        $this->fields_list['id_feature_value'] = array(
            'title' => $this->l('ID Feature Value'),
            'align' => 'center',
            'class' => 'fixed-width-xs',
            'type' => 'int',
            'value' => 1000
            #'value' => 'Hello'

        );
        $this->fields_list['name'] = array(
            'title' => $this->l('Name'),
          );

        $this->addRowAction('view');
        $this->addRowAction('edit');


        /*if (Configuration::get('PS_STOCK_MANAGEMENT')) {
            $this->fields_list['sav_quantity'] = array(
                'title' => $this->l('Quantity'),
                'type' => 'int',
                'align' => 'text-right',
                'filter_key' => 'sav!quantity',
                'orderby' => true,
                'badge_danger' => true,
                'search' => false
                //'hint' => $this->l('This is the quantity available in the current shop/group.'),
            );
        }*/

    }

    public function renderView()
    {
        echo "This is a render View"; die;
    }

    public function renderForm()
    {

        /*echo "HERE";
        die;*/

        #$this->addRowAction('edit');

        echo "This is a render Form";        die;
        $tpl = $this->context->smarty->createTemplate(dirname(__FILE__). '/../../views/templates/admin/view.tpl');

        #$this->addRowAction('delete');
        #return parent::renderList();
        return $tpl->fetch();

    }



    public function renderList()
    {
        if (!($this->fields_list && is_array($this->fields_list))) {
            return false;
        }
        $this->getList($this->context->language->id);


        $helper = new HelperList();

        // Empty list is ok
        if (!is_array($this->_list)) {
            $this->displayWarning($this->l('Bad SQL query', 'Helper') . '<br />' . htmlspecialchars($this->_list_error));
            return false;
        }

        $this->setHelperDisplay($helper);
        $helper->_default_pagination = $this->_default_pagination;
        $helper->_pagination = $this->_pagination;
        $helper->tpl_vars = $this->getTemplateListVars();
        $helper->tpl_delete_link_vars = $this->tpl_delete_link_vars;

        // For compatibility reasons, we have to check standard actions in class attributes
        foreach ($this->actions_available as $action) {
            if (!in_array($action, $this->actions) && isset($this->$action) && $this->$action) {
                $this->actions[] = $action;
            }
        }

        $helper->is_cms = $this->is_cms;
        $helper->sql = $this->_listsql;
        $list = $helper->generateList($this->_list, $this->fields_list);

        return $list;
    }

    /**
     * @return string
     */
   /* public function init()
    {
        parent::init();
    }*/

}