<?php

class TypePImport extends ObjectModel
{

    public $id_feature_value;
    public $name;


    public function __construct()
    {

    }
}