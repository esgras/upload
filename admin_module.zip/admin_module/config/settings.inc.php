<?php
define('_DB_SERVER_', 'worksite.mysql.ukraine.com.ua');
define('_DB_NAME_', 'worksite_nova');
define('_DB_USER_', 'worksite_nova');
define('_DB_PASSWD_', 'n2kkkssb');
define('_DB_PREFIX_', 'ps_');
define('_MYSQL_ENGINE_', 'InnoDB');
define('_PS_CACHING_SYSTEM_', 'CacheMemcache');
define('_PS_CACHE_ENABLED_', '0');
define('_COOKIE_KEY_', 'FVxsTkMyvkKk55PfDgHnqP0ksii1A56F913xuRPpqPeheiT9eOeLGB5I');
define('_COOKIE_IV_', 'p6ccXR1V');
define('_PS_CREATION_DATE_', '2017-04-04');
if (!defined('_PS_VERSION_'))
	define('_PS_VERSION_', '1.6.1.9');
define('_RIJNDAEL_KEY_', 'kLyHpJKFmpaIKfus12UIvMONTO0Ufdav');
define('_RIJNDAEL_IV_', 'PD/Oij1BM/0sjnFSf6Bw4Q==');
