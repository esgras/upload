<?php

Class VWbLightRozetkaGenerateModuleFrontController extends ModuleFrontController
{
    public function initContent()
    {
        parent::initContent();
        $action = Tools::getValue('action');
        switch ($action){
            case 'generate':
                $this->generate();
                break;
        }
    }

    private function generate()
    {
        $rozetka = VWbLightRozetka::LightRozetka();
        $rozetka->generate();
        echo _PS_BASE_URL_ . _THEME_PROD_PIC_DIR_ .'lightrozetka.xml';
        echo '<br>';    
        echo '<a href="'._PS_BASE_URL_ . _THEME_PROD_PIC_DIR_ .'lightrozetka.xml'.'">lightrozetka.xml</a>';
        die;
    }
}