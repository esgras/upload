<?php

if (!defined('_PS_VERSION_'))
    exit;

include_once 'classes/lightrozetka.php';

Class VWbLightRozetka extends Module
{
    public $cats;
    protected static $contact_fields = array(
        'VWB_LIGHT_Rozetka_NAME',
        'VWB_LIGHT_Rozetka_COMPANY'
    );


    public function __construct()
    {
        $this->name = 'vwblightrozetka';
        $this->tab = 'export';
        $this->version = '1.0.0';
        $this->author = 'ViWeb';
        $this->bootstrap = true;
        parent::__construct();

        $this->displayName = $this->l('Light Rozetka');
        $this->description = $this->l('Ускоренная выгрузка xml для Rozetka');
    }

    public function install()
    {
        return parent::install();
    }

    public function uninstall()
    {
        return parent::uninstall();
    }

    public function renderForm()
    {

        if ($categories = Configuration::get('VWB_LIGHT_Rozetka_CATEGORY')) {
            $unserializeCategories = unserialize($categories);
            if (is_array($unserializeCategories)) {
                $this->cats = $unserializeCategories;
            }
        }

        $fields_form = array(
            'form' => array(
                'legend' => array(
                    'title' => $this->l('Settings'),
                    'icon' => 'icon-cogs'
                ),
                'input' => array(
                    array(
                        'type' => 'text',
                        #'maxchar' => 20,
                        'label' => $this->l('Короткое название магазина'),
                        'name' => 'VWB_LIGHT_Rozetka_NAME'
                    ),

                    array(
                        'type' => 'text',
                        'label'=> $this->l('Полное наименование компании'),
                        'name' => 'VWB_LIGHT_Rozetka_COMPANY'
                    ),
                    array(
                        'type' => 'text',
                        'label' => $this->l('Статическая ссылка'),
                        'desc' => $this->l('Ссылка для генерации файла'),
                        'name' => 'static_generate',
                    ),
                    array(
                        'type' => 'text',
                        'label' => $this->l('Статическая ссылка'),
                        'desc' => $this->l('Ссылка для просмотра файла'),
                        'name' => 'static_url',
                    ),
                ),
                'submit' => array(
                    'title' => $this->l('Save')
                )
            ),
        );

        $helper = new HelperForm();
        $helper->show_toolbar = false;
        $helper->table = $this->table;
        $lang = new Language((int)Configuration::get('PS_LANG_DEFAULT'));
        $helper->default_form_language = $lang->id;
        $helper->allow_employee_form_lang = Configuration::get('PS_BO_ALLOW_EMPLOYEE_FORM_LANG') ?
            Configuration::get('PS_BO_ALLOW_EMPLOYEE_FORM_LANG') : 0;
        $this->fields_form = array();
        $helper->identifier = $this->identifier;
        $helper->submit_action = 'submitModule';
        $helper->currentIndex = $this->context->link->
            getAdminLink('AdminModules', false) . '&configure=' .
            $this->name . '&tab_module=' . $this->tab . '&module_name=' . $this->name;
        $helper->token = Tools::getAdminTokenLite('AdminModules');
        $helper->tpl_vars = array(
            'fields_value' => array(),
            'languages' => $this->context->controller->getLanguages(),
            'id_language' => $this->context->language->id
        );


        $helper->tpl_vars['fields_value']['VWB_LIGHT_Rozetka_NAME'] = Configuration::get('VWB_LIGHT_Rozetka_NAME');
        $helper->tpl_vars['fields_value']['VWB_LIGHT_Rozetka_COMPANY'] = Configuration::get('VWB_LIGHT_Rozetka_COMPANY');
        $helper->tpl_vars['fields_value']['static_generate'] = $this->context->link->getModuleLink('vwblightrozetka', 'generate', array('action' => 'generate'));
        $helper->tpl_vars['fields_value']['static_url'] = _PS_BASE_URL_ . _THEME_PROD_PIC_DIR_ . 'lightrozetka.xml';

        return $helper->generateForm(array($fields_form));
    }

    public function getContent()
    {
        $html = '';
        if (Tools::isSubmit('submitModule')) {
            $rozetka_name = substr(Tools::getValue('VWB_LIGHT_Rozetka_NAME'), 0, 20);

            Configuration::updateValue('VWB_LIGHT_Rozetka_NAME', $rozetka_name);
            Configuration::updateValue('VWB_LIGHT_Rozetka_COMPANY', Tools::getValue('VWB_LIGHT_Rozetka_COMPANY'));

            $html = $this->displayConfirmation($this->l('Настройки обновлены'));
        }
        return $html . $this->renderForm();
    }

    static public function LightRozetka()
    {
        return new LightRozetka();
    }
}