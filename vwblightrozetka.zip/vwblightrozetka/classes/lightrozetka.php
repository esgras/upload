<?php

Class LightRozetka
{
    public $file;
    public $xmlContent;
    public $cats;
    public $offers;
    public $context;
    public $currency_name;
    public $name;
    public $company;

    function __construct()
    {
        $this->context = Context::getContext();
        $this->currency_name = $this->getCurrency();
        $this->company = $this->getCompany();
        $this->name = $this->getName();
        /*d($this->name);
        var_dump($this->company);
        var_dump($this->name);
        die;*/

        #d("I'm here");
        if (file_exists(_PS_UPLOAD_DIR_ . 'lightrozetka.xml')) {
            unlink(_PS_UPLOAD_DIR_ . 'lightrozetka.xml');
        }
    }

    public function getCategories()
    {

        if ($categories = Configuration::get('VWB_LIGHT_Rozetka_CATEGORY')) {
            $unserializeCategories = unserialize($categories);
            if (is_array($unserializeCategories))
                $this->cats = $unserializeCategories;
            $this->cats = implode(',', $this->cats);
        }

        $langId = $this->getLangId();

        $query = 'SELECT `category`.id_category, `category`.id_parent, `lang`.name FROM `' . _DB_PREFIX_ . 'category` AS category
                  LEFT JOIN `' . _DB_PREFIX_ . 'category_lang` AS lang
                  ON (`category`.id_category = `lang`.id_category)
                  WHERE active = 1 AND id_lang=' . (int) $langId;
        /*
        if ($this->cats) {
            $query .= 'AND `category`.id_category IN (' . $this->cats . ')';
        }
        */

        $res = DB::getInstance()->executeS($query);
        return $res;
    }

   # public function

    public function adfdProduct($category)
    {
        $langId = $this->getLangId();
        $products = DB::getInstance()->executeS('SELECT `lang`.name, `lang`.id_lang,
                                                            `lang`.description_short,
                                                            `product`.price,
                                                            `product`.id_product,
                                                            `product`.id_category_default,
                                                            `product`.active,
                                                            `manufacturer`.name AS manufacturer_name
                                         FROM `' . _DB_PREFIX_ . 'product_lang` AS lang
                                         LEFT JOIN `' . _DB_PREFIX_ . 'product` AS product
                                         ON (`product`.id_product = `lang`.id_product)
                                         LEFT JOIN `' . _DB_PREFIX_. 'manufacturer` AS manufacturer
                                         ON (`product`.id_manufacturer = `manufacturer`.id_manufacturer)
                                         WHERE `product`.id_category_default = ' . $category['id_category'] . '
                                         AND `product`.active = 1 AND `lang`.id_lang=' . $langId);
        $this->addOffers($products);
    }

    public function addOffers($products)
    {
        #d($products);
        #$this->offers = '';
        if (is_array($products) && !empty($products)) {
            foreach ($products as $product) {

                $this->offers .= '<offer id="' . $product['id_product'] . '" available="' . ($product['active'] ? 'true':'false') .'">';
                $this->offers .= '<url>' . $this->context->link->getProductLink((int)$product['id_product']) . '</url>';
                $this->offers .= '<price>' . round($product['price'],2)   . '</price>';
                $this->offers .= '<currencyId>' . $this->currency_name . '</currencyId>';
                $this->offers .= '<categoryId>' . $product['id_category_default'] . '</categoryId>';

                //Получить картинки
                $langId = $this->context->language->id;
                $prod = new Product($product['id_product']);

                $images = $prod->getImages($langId);

                foreach ($images as $img) {

                    $imageUrl = $this->context->link->getImageLink($prod->link_rewrite[1], $img['id_image'], 'home_default');
                    $this->offers .= '<picture>' . $imageUrl . '</picture>';
                }

                $this->offers .= '<name>' . htmlspecialchars($product['name']) . '</name>';
                $this->offers .= '<vendor>' . $this->e($product['manufacturer_name']) .' </vendor>';
                $this->offers .= '<description><![CDATA[' . htmlspecialchars($product['description_short']) . ']]></description>';

                $featuresArray = $prod->getFeatures();


                foreach ($featuresArray as $feat) {
                    $feature = Feature::getFeature($langId, $feat['id_feature']);
                    $featureName = $feature['name'];
                    $featureValue = $this->getValueFromFeatureValueByLanguage($langId, $feat['id_feature_value']);

                    $this->offers .= '<param name="'.$featureName.'">'.$featureValue.'</param>';
                }

                $this->offers .= '</offer>';
            }
        }
        $this->write(_PS_UPLOAD_DIR_ . 'lightrozetka.xml', $this->offers);
        unset($this->offers);
        $this->offers = '';
    }

    public function xmlHeader()
    {
        return '<?xml version="1.0" encoding="UTF-8"?><!DOCTYPE yml_catalog SYSTEM "shops.dtd">';
    }

    public function xmlStartRootDirectory()
    {
        $out = '<yml_catalog date="' . date('Y-m-d H:i') . '"><shop>';
        $out .= '<name>' . $this->name . '</name>';
        $out .= '<company>' . $this->company . '</company>';
        $out .= '<url>' . _PS_BASE_URL_ . '</url>';
        $out .= '<currencies><currency id="' . $this->getCurrency() . '" rate="1"/></currencies>';

        return $out;
    }

    public function xmlEndRootDirectory()
    {
        return '</shop></yml_catalog>';
    }

    public function getCurrency()
    {
        return DB::getInstance()->getValue('SELECT `iso_code` 
                                                            FROM `' . _DB_PREFIX_ . 'currency` 
                                                            WHERE id_currency = ' . $this->context->cart->id_currency);
    }

    public function generate()
    {
        $this->xmlContent = $this->xmlHeader();
        $this->xmlContent .= $this->xmlStartRootDirectory();
        $this->write(_PS_UPLOAD_DIR_ . 'lightrozetka.xml', $this->xmlContent);

        $categories = $this->getCategories();

        $this->xmlContent = '<categories>';
        foreach ($categories as $category) {
            if ($category['id_category'] == 1) continue;

            $parentId = !empty($category['id_parent']) ? ' parentId="'.$category['id_parent'].'"' : '';
            $this->xmlContent .= '<category id="' . $category['id_category'] . '"' .
                $parentId . '>' . $category['name'] . '</category>';
        }
        $this->xmlContent .= '</categories>';

        $this->write(_PS_UPLOAD_DIR_ . 'lightrozetka.xml', $this->xmlContent);


        $this->offers = '<offers>';
        foreach ($categories as $category) {
            $this->addProduct($category);
        }
        $this->xmlContent = '</offers>';
        $this->xmlContent .= $this->xmlEndRootDirectory();
        $this->write(_PS_UPLOAD_DIR_ . 'lightrozetka.xml', $this->xmlContent);
        unset($this->xmlContent);
    }



    public function write($filenamewr, $text)
    {
        if (($filenamewr)) {
            $handle = fopen($filenamewr, 'a');
            if (!$handle) {
                echo "Не могу открыть файл ($filenamewr)";
                exit;
            }

            if (fwrite($handle, $text) === FALSE) {
                echo "Не могу произвести запись в файл ($filenamewr)";
                exit;
            }

            fclose($handle);
        } else {
            echo "Файл $filenamewr недоступен для записи";
        }
    }

    public function e($text) {
        return htmlspecialchars($text, ENT_QUOTES, 'UTF-8');
    }


    public function getValueFromFeatureValueByLanguage ($id_lang, $id_feature_value)
    {
        return Db::getInstance()->getValue('SELECT `value` FROM `'._DB_PREFIX_.'feature_value_lang` 
			WHERE `id_feature_value` = '.(int)$id_feature_value.' AND id_lang= ' . (int) $id_lang

		);
    }

    public function getName() {
        return $this->name = Configuration::get('VWB_LIGHT_Rozetka_NAME');
    }

    public function getCompany() {
        return $this->name = Configuration::get('VWB_LIGHT_Rozetka_COMPANY');
    }

    public function getLangId() {
        return $this->context->language->id;
    }
}